[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Oswald&weight=600&size=27&pause=1000&color=F75DF4&center=true&vCenter=true&random=true&width=435&lines=Como+Pedir+Algu%C3%A9m+em+Namoro+%F0%9F%A5%B5%F0%9F%A5%B5)](https://git.io/typing-svg)

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Oswald&weight=600&size=27&pause=1000&color=FF5733&center=true&vCenter=true&random=true&width=435&lines=Como+Pedir+Algu%C3%A9m+em+Namoro+%F0%9F%A5%B5%F0%9F%A5%B5)](https://git.io/typing-svg)

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Oswald&weight=600&size=27&pause=1000&color=33FF57&center=true&vCenter=true&random=true&width=435&lines=Como+Pedir+Algu%C3%A9m+em+Namoro+%F0%9F%A5%B5%F0%9F%A5%B5)](https://git.io/typing-svg)

## Guia Final para Conseguir um Par Real
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Oswald&weight=500&size=18&pause=3000&color=3873F7&center=true&vCenter=true&random=true&width=435&lines=Oficial+sem+V%C3%ADrus+%E2%80%93+%C3%9Altima+Edi%C3%A7%C3%A3o+Deluxe+360p+Dublado+%F0%9F%90%93)](https://git.io/typing-svg)


### 📊 Como conseguir um(a) par? Google pesquisar

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304052269/33FE849B6912BD519C78F39C5E1C3B51D31B9DD2/)
![Imagem](https://st4.depositphotos.com/4744673/20129/i/450/depositphotos_201291672-stock-photo-young-funny-geek-nerd-woman.jpg)

Oi, esse é meu guia fantástico e revolucionário pra ajudar vocês a conseguirem um par. Sim, isso mesmo, vocês aí do outro lado da tela!!!! 🐎💩 Hoje é o dia em que vocês vão finalmente descobrir como arrumar o amor da vida de uma vez por todas. 🦃🦃🦃🦃🦃

Porque eu sei que a "vida" amorosa de um(a) jogador(a) de Minecraft não é das mais fáceis. Sim, eu sei como as pessoas pensam que vocês são ESTRANHOS E BIZARROS, mas isso muda hoje. Eu tô aqui pra ajudar a mudar a vida de vocês. :)

### 1. DESINSTALE O STARDEW VALLEY

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304088764/1027E3503B55F557FE0F0E80537D7181ADDC8452/)

Acreditem em mim, essa parte é crucial. Experiência própria. 😔✊

### 2. Ache um Par Ideal

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304151402/A21DD9D8D281E148C84F86197C043E508F23A58A/)

Uma dica: não sejam muito exigentes. Até porque vocês são feios 🤡

É, vocês são feios. Ou melhor, vocês são disbunidos. Quer dizer, falta beleza ou são bonitos por dentro, mas pena que não por fora. Não, não digo, vocês são judiados, estragados?? Filhotes de saruê.

Quer saber? Acho que vocês já entenderam.

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304950714/302473D1CA8BD34BFA6B58182160605200D58AD5/)

### 3. Fiquem Lindos

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304293906/5F7015241FED8D2353F6B62C44797F1958FA03AB/)

Ou melhor, éhh...

No caso de vocês, só fiquem menos feios mesmo ☠️☠️

*Oferecimento Manual: Lutando contra a calvície desde 1945*

### 4. Ativem o Modo Anti-calvice V8

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304224192/F16164BAFD96B3E34B508B044758D7A9660EA7DC/)

Torna vocês irresistíveis a qualquer pessoa 🥵🥵

### 5. Convidem a Pessoa para Sair

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304445548/F544E7140033409C6ECDF2EE05C90911FBF4B1A1/)

Se ela (ou ele) recusar, sempre podem partir pra chantagem, ameaça e agressão. Sei lá, sejam criativos :) 🤬🤜

Se tudo der certo, ótimo! Vocês têm um encontro agora. Vamos preparar vocês. 🤯🤯

### 6. Uniforme

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748305022665/E37880A686AD89F5535E79055328AC299C267F6D/)

O DRIP tem que permanecer 😎😎

### 7. Equipamentos Essenciais

![Imagem](https://i.pinimg.com/736x/0c/dd/9e/0cdd9ec25011bd62a82b212cf750377a.jpg)

### 8. Encontro

![Imagem](https://steamuserimages-a.akamaihd.net/ugc/2484381748304606884/34D14497456FD80D029B2075D6313E0B03B02FBE/)

Dica: Não perguntem se a pessoa gosta do RPG do Cellbit, nem se joga o grande MINECRAFT, no primeiro encontro (NEM QUE JOGA LOL 🤬), confiem em mim, já testei e não funciona 🤓🤓

O Programa do Ratinho não é um bom lugar pra um primeiro encontro 🐀

### 9. Etapa Final

Ok, agora que vocês já aprenderam tudo, vamos finalmente pra última e mais importante parte.

### 10. Após o Encontro

Envie o link da página para a pessoa 😎😎

Ou, se preferir, faça um **fork** do repositório para sua própria conta do GitHub e envie o arquivo `index.html`. Após alguns minutos, sua página estará disponível no link fornecido na seção "Pages" das configurações do repositório.

Espere a resposta dele(a) (infalível).

### Considerações Finais

Esse foi o guia, meus amigos geniais e legais. Aparentemente, não dá certo alguém sem um par tentar ensinar os outros a como ter um par 🤠

Deixem o like e se inscrevam se quiserem um guia de como falsificar nota de 100 cruzeiros. Se não quiserem, deixem o like também, vão ser cobrados pelo morro da Jabuticaba, o mais perigoso do Acre 🤫

É isso e falou, meus peixes. Até a próxima, aqui é o Zywl na voz. 🐟🐟😬😬

---
